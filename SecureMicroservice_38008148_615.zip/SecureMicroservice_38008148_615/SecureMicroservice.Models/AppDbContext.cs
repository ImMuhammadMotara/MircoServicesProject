﻿using Microsoft.EntityFrameworkCore;
using SecureMicroservice.Models.Entities;

namespace SecureMicroservice.Models.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Product> Products { get; set; }
    public DbSet<User> Users { get; set; }
}