﻿namespace SecureMicroservice.Models
{
    public class Class1
    {

    }
}