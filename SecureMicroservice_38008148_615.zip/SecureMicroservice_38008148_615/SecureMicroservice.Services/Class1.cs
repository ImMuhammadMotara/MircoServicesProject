﻿namespace SecureMicroservice.Services
{
    public class Class1
    {

    }
}